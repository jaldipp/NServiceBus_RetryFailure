﻿using System;
using System.IO;
using NServiceBus;
using NServiceBus.Config;
using NServiceBus.Config.ConfigurationSource;

namespace WorkerRole
{
    public class EndpointConfig : IConfigureThisEndpoint, AsA_Worker
    {
        public void Customize(BusConfiguration configuration)
        {
            configuration.EndpointName("repro-jaldip");
            configuration.UseTransport<AzureStorageQueueTransport>();
            configuration.UsePersistence<InMemoryPersistence>();
        }
    }


    public class ConfigureTransport : IProvideConfiguration<TransportConfig>
    {
        public TransportConfig GetConfiguration()
        {
            return new TransportConfig()
            {
                MaxRetries = 2,
                MaximumConcurrencyLevel = 1,
            };
        }
    }

    public class ConfigureErrorQueue : IProvideConfiguration<MessageForwardingInCaseOfFaultConfig>
    {
        public MessageForwardingInCaseOfFaultConfig GetConfiguration()
        {
            return new MessageForwardingInCaseOfFaultConfig()
            {
                ErrorQueue = "error"
            };
        }
    }

    public class ConfigureAuditQueue : IProvideConfiguration<AuditConfig>
    {
        public AuditConfig GetConfiguration()
        {
            return new AuditConfig()
            {
                QueueName = "audit"
            };
        }
    }

    public class ConfigureSLR : IProvideConfiguration<SecondLevelRetriesConfig>
    {
        public SecondLevelRetriesConfig GetConfiguration()
        {
            return new SecondLevelRetriesConfig()
            {
                Enabled = true,
                TimeIncrease = TimeSpan.FromSeconds(5),
                NumberOfRetries = 2
            };
        }
    }

    public class ConfigureASQ : IProvideConfiguration<AzureQueueConfig>
    {
        public AzureQueueConfig GetConfiguration()
        {
            return new AzureQueueConfig()
            {
                ConnectionString = ConnectionStringReader.Get().Transport,
            };
        }
    }


    public class ConnectionStringReader
    {
        public static ConnectionStrings Get()
        {
            var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "connectionstrings.json");
            return Newtonsoft.Json.JsonConvert.DeserializeObject<ConnectionStrings>(File.ReadAllText(filePath));
        }
    }

    /*
     Required: connectionstring.json file in the following format
        {
            "Transport": "Endpoint=sb://[namespace].servicebus.windows.net/;Shared...",
            "Persistence": "DefaultEndpointsProtocol=https;AccountName=[account];AccountKey=..."
        }
     */

    public class ConnectionStrings
    {
        public string Transport { get; set; }
        public string Persistence { get; set; }
    }
}
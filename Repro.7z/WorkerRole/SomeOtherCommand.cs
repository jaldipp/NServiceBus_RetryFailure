﻿using NServiceBus;

namespace WorkerRole
{
    public class SomeOtherCommand : ICommand
    {
        public string CausedBy { get; set; }
    }
}
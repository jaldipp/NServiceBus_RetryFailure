﻿using NServiceBus;
using NServiceBus.Logging;
using Repro.Host;

namespace WorkerRole
{
    public class SomeCommandHandler : IHandleMessages<SomeCommand>
    {
        private ILog logger = LogManager.GetLogger<SomeCommandHandler>();

        public IBus Bus { get; set; }

        public void Handle(SomeCommand message)
        {
            logger.Info("Received SomeCommand from " + message.When);
            logger.Info("and throwing exception");
            Bus.Send("507A4549-DD24-470B-9F14-E205BAC562F", new SomeOtherCommand {CausedBy = Bus.CurrentMessageContext.Id});
        }
    }
}
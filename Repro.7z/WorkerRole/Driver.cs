﻿using System;
using System.Diagnostics;
using NServiceBus;
using Repro.Host;

namespace WorkerRole
{
    public class Driver : IWantToRunWhenBusStartsAndStops
    {
        private static bool hasFired = false;
        public IBus Bus { get; set; }

        public void Start()
        {
            if (!hasFired)
            {
                Trace.TraceInformation("Dispatching SomeCommand to kick off repro");
                Bus.SendLocal(new SomeCommand { When = DateTime.Now });
            }
        }

        public void Stop()
        {
        }
    }
}
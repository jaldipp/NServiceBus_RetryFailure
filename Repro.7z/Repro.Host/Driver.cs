﻿using System;
using NServiceBus;

namespace Repro.Host
{
    public class Driver : IWantToRunWhenBusStartsAndStops
    {
        public IBus Bus { get; set; }

        public void Start()
        {
            Bus.SendLocal(new SomeCommand {When = DateTime.Now});
        }

        public void Stop()
        {
        }
    }
}
﻿using System;
using NServiceBus;

namespace Repro.Host
{
    public class SomeCommand : ICommand
    {
        public DateTime When { get; set; }
    }
}
﻿using System;
using NServiceBus;
using NServiceBus.Logging;

namespace Repro.Host
{
//    public class SomeCommandHandler : IHandleMessages<SomeCommand>
//    {
//        private ILog logger = LogManager.GetLogger<SomeCommandHandler>();
//
//        public IBus Bus { get; set; }
//
//        public void Handle(SomeCommand message)
//        {
//            logger.Info("Received SomeCommand from " + message.When);
//            logger.Info("and throwing exception");
//            // throw new Exception("processing failed"); failing processing with exception -- works
//            Bus.Send("507A4549-DD24-470B-9F14-E205BAC562F", new SomeOtherCommand {CausedBy = Bus.CurrentMessageContext.Id});
//        }
//    }
}
﻿using NServiceBus;

namespace Repro.Host
{
    public class SomeOtherCommand : ICommand
    {
        public string CausedBy { get; set; }
    }
}